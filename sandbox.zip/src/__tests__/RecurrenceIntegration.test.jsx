import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { RecurrenceProvider } from "../context/RecurrenceContext";
import App from "../App"; // Your main app with StartDate, RecurrenceOptions, and MiniCalendarPreview

test("integration: selecting date shows calendar preview", () => {
  render(
    <RecurrenceProvider>
      <App />
    </RecurrenceProvider>
  );

  const input = screen.getByLabelText(/start date/i);
  fireEvent.change(input, { target: { value: "2025-07-20" } });

  expect(screen.getByText(/starting Jul 20, 2025/i)).toBeInTheDocument();
});
