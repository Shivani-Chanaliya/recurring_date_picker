import { getRepeatText } from "./getRepeatText";

describe("getRepeatText utility", () => {
  it("should return 'Repeat every day' for interval 1", () => {
    expect(getRepeatText("day", 1)).toBe("Repeat every day");
  });

  it("should return 'Repeat every 3 weeks' for interval > 1", () => {
    expect(getRepeatText("week", 3)).toBe("Repeat every 3 weeks");
  });

  it("should return 'Repeat every 2 months'", () => {
    expect(getRepeatText("month", 2)).toBe("Repeat every 2 months");
  });
});
