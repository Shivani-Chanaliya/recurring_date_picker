export const getRepeatText = (frequency, interval) => {
  if (interval === 1) {
    return `Repeat every ${frequency}`;
  }
  return `Repeat every ${interval} ${frequency}s`;
};
