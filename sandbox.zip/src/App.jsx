import React from "react";
import { RecurrenceProvider } from "./context/RecurrenceContext";
import RecurrenceTypeSelector from "./components/RecurrenceTypeSelector";
import IntervalSelector from "./components/IntervalSelector";
import WeekDays from "./components/WeekDays";
import MonthlyPatternSelector from "./components/MonthlyPatternSelector";
import DateRangePicker from "./components/DateRangePicker";
import MiniCalendarPreview from "./components/MiniCalendarPreview";

const App = () => {
  return (
    <RecurrenceProvider>
      <div className="min-h-screen p-6 bg-gray-100 text-gray-800">
        <h1 className="text-3xl font-bold mb-4 text-center">
          Recurring Date Picker
        </h1>
        <div className="space-y-4">
          <RecurrenceTypeSelector />
          <IntervalSelector />
          <WeekDays />
          <MonthlyPatternSelector />
          <DateRangePicker />
          <MiniCalendarPreview />
        </div>
      </div>
    </RecurrenceProvider>
  );
};

export default App;
