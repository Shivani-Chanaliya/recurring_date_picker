import React from "react";
import { useRecurrence } from "../context/RecurrenceContext";

const RecurrenceOptions = () => {
  const {
    recurrenceType,
    setRecurrenceType,
    interval,
    setInterval,
    weekDays,
    setWeekDays,
    monthlyPattern,
    setMonthlyPattern
  } = useRecurrence();

  const handleWeekdayChange = (day) => {
    if (weekDays.includes(day)) {
      setWeekDays(weekDays.filter((d) => d !== day));
    } else {
      setWeekDays([...weekDays, day]);
    }
  };

  return (
    <div className="space-y-4">
      {/* Recurrence Type */}
      <div>
        <label className="block font-medium mb-1">Recurrence Type</label>
        <select
          value={recurrenceType}
          onChange={(e) => setRecurrenceType(e.target.value)}
          className="border p-2 w-full"
        >
          <option value="daily">Daily</option>
          <option value="weekly">Weekly</option>
          <option value="monthly">Monthly</option>
          <option value="yearly">Yearly</option>
        </select>
      </div>

      {/* Interval */}
      <div>
        <label className="block font-medium mb-1">Every</label>
        <input
          type="number"
          min="1"
          value={interval}
          onChange={(e) => setInterval(Number(e.target.value))}
          className="border p-2 w-full"
        />
        <p className="text-sm text-gray-600">
          {`Every ${interval} ${recurrenceType}(s)`}
        </p>
      </div>

      {/* Weekly Days */}
      {recurrenceType === "weekly" && (
        <div>
          <label className="block font-medium mb-1">Select Days</label>
          <div className="flex flex-wrap gap-2">
            {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].map(
              (day) => (
                <button
                  key={day}
                  type="button"
                  onClick={() => handleWeekdayChange(day)}
                  className={`px-3 py-1 border rounded ${
                    weekDays.includes(day) ? "bg-blue-500 text-white" : "bg-gray-100"
                  }`}
                >
                  {day}
                </button>
              )
            )}
          </div>
        </div>
      )}

      {/* Monthly Pattern */}
      {recurrenceType === "monthly" && (
        <div>
          <label className="block font-medium mb-1">Monthly Pattern</label>
          <div className="flex gap-4">
            <select
              value={monthlyPattern.week}
              onChange={(e) =>
                setMonthlyPattern({ ...monthlyPattern, week: Number(e.target.value) })
              }
              className="border p-2"
            >
              {[1, 2, 3, 4, 5].map((week) => (
                <option key={week} value={week}>
                  {week}
                </option>
              ))}
            </select>
            <select
              value={monthlyPattern.day}
              onChange={(e) =>
                setMonthlyPattern({ ...monthlyPattern, day: e.target.value })
              }
              className="border p-2"
            >
              {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].map(
                (day) => (
                  <option key={day} value={day}>
                    {day}
                  </option>
                )
              )}
            </select>
          </div>
        </div>
      )}
    </div>
  );
};

export default RecurrenceOptions;
