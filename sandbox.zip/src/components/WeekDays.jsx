import React from "react";
import { useRecurrence } from "../context/RecurrenceContext";

const daysOfWeek = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];

const WeekDays = () => {
  const { recurrenceType, weekDays, setWeekDays } = useRecurrence();

  const toggleDay = (day) => {
    if (weekDays.includes(day)) {
      setWeekDays(weekDays.filter((d) => d !== day));
    } else {
      setWeekDays([...weekDays, day]);
    }
  };

  if (recurrenceType !== "weekly") return null;

  return (
    <div className="mb-4">
      <label className="block mb-2 font-semibold">Select Days</label>
      <div className="flex flex-wrap gap-2">
        {daysOfWeek.map((day) => (
          <button
            key={day}
            onClick={() => toggleDay(day)}
            className={`px-3 py-1 border rounded ${
              weekDays.includes(day) ? "bg-blue-600 text-white" : "bg-white"
            }`}
          >
            {day}
          </button>
        ))}
      </div>
    </div>
  );
};

export default WeekDays;
