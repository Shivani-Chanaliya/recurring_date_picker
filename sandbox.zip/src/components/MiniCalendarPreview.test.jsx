import React from "react";
import { render } from "@testing-library/react";
import { RecurrenceProvider } from "../context/RecurrenceContext";
import MiniCalendarPreview from "./MiniCalendarPreview";

test("displays prompt if no start date selected", () => {
  const { getByText } = render(
    <RecurrenceProvider>
      <MiniCalendarPreview />
    </RecurrenceProvider>
  );

  expect(getByText("Select a start date")).toBeInTheDocument();
});
