import React from "react";
import { useRecurrence } from "../context/RecurrenceContext";

const RecurrenceTypeSelector = () => {
  const { recurrenceType, setRecurrenceType } = useRecurrence();

  return (
    <div className="mb-4">
      <label className="block mb-2 font-semibold">Recurrence Type</label>
      <select
        value={recurrenceType}
        onChange={(e) => setRecurrenceType(e.target.value)}
        className="w-full border px-3 py-2 rounded"
      >
        <option value="daily">Daily</option>
        <option value="weekly">Weekly</option>
        <option value="monthly">Monthly</option>
        <option value="yearly">Yearly</option>
      </select>
    </div>
  );
};

export default RecurrenceTypeSelector;
