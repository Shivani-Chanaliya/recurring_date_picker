import React from "react";
import { useRecurrence } from "../context/RecurrenceContext";

const weeks = ["First", "Second", "Third", "Fourth", "Last"];
const days = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];

const IntervalSelector = () => {
  const {
    interval,
    setInterval,
    recurrenceType,
    setRecurrenceType,
    weekDays,
    toggleWeekDay,
    monthlyPattern,
    setMonthlyPattern,
  } = useRecurrence();

  const handleIntervalChange = (e) => {
    const value = parseInt(e.target.value, 10);
    if (!isNaN(value) && value > 0) {
      setInterval(value);
    }
  };

  return (
    <div className="mb-6">
      <label className="block font-semibold mb-2">Repeat Every:</label>
      <div className="flex space-x-3 items-center mb-4">
        <input
          type="number"
          min="1"
          className="border rounded px-3 py-1 w-20"
          value={interval}
          onChange={handleIntervalChange}
        />
        <select
          className="border rounded px-3 py-1"
          value={recurrenceType}
          onChange={(e) => setRecurrenceType(e.target.value)}
        >
          <option value="daily">day(s)</option>
          <option value="weekly">week(s)</option>
          <option value="monthly">month(s)</option>
          <option value="yearly">year(s)</option>
        </select>
      </div>

      {recurrenceType === "weekly" && (
        <div className="mb-4">
          <label className="block font-medium mb-1">Select Weekdays:</label>
          <div className="flex flex-wrap gap-2">
            {days.map((day) => (
              <button
                key={day}
                className={`px-2 py-1 rounded border ${
                  weekDays.includes(day)
                    ? "bg-blue-500 text-white"
                    : "bg-white text-gray-800"
                }`}
                onClick={() => toggleWeekDay(day)}
                type="button"
              >
                {day}
              </button>
            ))}
          </div>
        </div>
      )}

      {recurrenceType === "monthly" && (
        <div className="grid grid-cols-2 gap-4 mt-3">
          <div>
            <label className="block font-medium mb-1">Week:</label>
            <select
              className="border rounded px-3 py-1 w-full"
              value={monthlyPattern.week}
              onChange={(e) =>
                setMonthlyPattern({ ...monthlyPattern, week: e.target.value })
              }
            >
              {weeks.map((week) => (
                <option key={week} value={week}>
                  {week}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block font-medium mb-1">Day:</label>
            <select
              className="border rounded px-3 py-1 w-full"
              value={monthlyPattern.day}
              onChange={(e) =>
                setMonthlyPattern({ ...monthlyPattern, day: e.target.value })
              }
            >
              {days.map((day) => (
                <option key={day} value={day}>
                  {day}
                </option>
              ))}
            </select>
          </div>
        </div>
      )}
    </div>
  );
};

export default IntervalSelector;
