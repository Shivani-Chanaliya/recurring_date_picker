import React from "react";
import { useRecurrence } from "../context/RecurrenceContext";

const weeks = [1, 2, 3, 4, 5];
const days = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];

const MonthlyPatternSelector = () => {
  const { recurrenceType, monthlyPattern, setMonthlyPattern } = useRecurrence();

  if (recurrenceType !== "monthly") return null;

  const handleChange = (field, value) => {
    setMonthlyPattern({ ...monthlyPattern, [field]: value });
  };

  return (
    <div className="mb-4">
      <label className="block mb-2 font-semibold">Select Monthly Pattern</label>
      <div className="flex gap-4">
        <select
          value={monthlyPattern.week}
          onChange={(e) => handleChange("week", parseInt(e.target.value))}
          className="border px-2 py-1 rounded"
        >
          {weeks.map((w) => (
            <option key={w} value={w}>
              {w}
            </option>
          ))}
        </select>
        <select
          value={monthlyPattern.day}
          onChange={(e) => handleChange("day", e.target.value)}
          className="border px-2 py-1 rounded"
        >
          {days.map((d) => (
            <option key={d} value={d}>
              {d}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
};

export default MonthlyPatternSelector;
