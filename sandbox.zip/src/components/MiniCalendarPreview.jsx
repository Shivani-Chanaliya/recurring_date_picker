import React from "react";
import { useRecurrence } from "../context/RecurrenceContext.jsx"; // Correct path
import { format } from "date-fns";

const getRepeatText = (interval, count) => {
  const singular = {
    daily: "day",
    weekly: "week",
    monthly: "month",
    yearly: "year",
  };

  const plural = {
    daily: "days",
    weekly: "weeks",
    monthly: "months",
    yearly: "years",
  };

  return count === 1
    ? `Repeats every ${singular[interval]}`
    : `Repeats every ${count} ${plural[interval]}`;
};

const MiniCalendarPreview = () => {
  const {
    interval,
    recurrenceType,
    startDate,
    endDate,
  } = useRecurrence();

  const renderPreview = () => {
    if (!startDate) return "Please select a start date.";

    const formattedStart = format(new Date(startDate), "PPP");
    const formattedEnd = endDate ? format(new Date(endDate), "PPP") : "No end date";

    const repeatText = getRepeatText(recurrenceType, interval);
    return `${repeatText}, starting ${formattedStart}, ending ${formattedEnd}`;
  };

  return (
    <div className="mt-4 p-4 border rounded bg-white shadow">
      <h2 className="text-lg font-semibold mb-2">Recurrence Preview</h2>
      <p>{renderPreview()}</p>
    </div>
  );
};

export default MiniCalendarPreview;
