import React from "react";
import { useRecurrence } from "../context/RecurrenceContext";

const DateRangePicker = () => {
  const { startDate, setStartDate, endDate, setEndDate } = useRecurrence();

  return (
    <div className="mb-4">
      <label className="block mb-2 font-semibold">Start Date</label>
      <input
        type="date"
        value={startDate}
        onChange={(e) => setStartDate(e.target.value)}
        className="border px-2 py-1 rounded w-full mb-4"
      />
      <label className="block mb-2 font-semibold">End Date (optional)</label>
      <input
        type="date"
        value={endDate}
        onChange={(e) => setEndDate(e.target.value)}
        className="border px-2 py-1 rounded w-full"
      />
    </div>
  );
};

export default DateRangePicker;
